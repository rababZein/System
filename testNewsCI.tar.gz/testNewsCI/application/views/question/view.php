<?php
echo '<h2>'.$questions_item['Q_Name'].'</h2>';
