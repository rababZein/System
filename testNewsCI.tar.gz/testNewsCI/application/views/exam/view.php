<?php
echo '<h2>'.$exams_item['Exam_Name'].'</h2>';
echo $exams_item['Exam_Desc'];